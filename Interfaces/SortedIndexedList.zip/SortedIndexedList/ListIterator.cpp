#include "ListIterator.h"
#include "SortedIndexedList.h"
#include <iostream>

using namespace std;

ListIterator::ListIterator(const SortedIndexedList& list) : list(list) {
	//TODO - Implementation
}

void ListIterator::first(){
	//TODO - Implementation
}

void ListIterator::next(){
	//TODO - Implementation
}

bool ListIterator::valid() const{
	//TODO - Implementation
	return false;
}

TComp ListIterator::getCurrent() const{
	//TODO - Implementation
	return NULL_TCOMP;
}


