#include "SortedSetIterator.h"
#include <exception>

using namespace std;

SortedSetIterator::SortedSetIterator(const SortedSet& m) : multime(m)
{
	//TODO - Implementation
}


void SortedSetIterator::first() {
	//TODO - Implementation
}


void SortedSetIterator::next() {
	//TODO - Implementation
}


TElem SortedSetIterator::getCurrent()
{
	//TODO - Implementation
	return NULL_TELEM;
}

bool SortedSetIterator::valid() const {
	//TODO - Implementation
	return false;
}

