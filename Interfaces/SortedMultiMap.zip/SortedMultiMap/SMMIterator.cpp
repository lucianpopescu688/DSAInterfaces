#include "SMMIterator.h"
#include "SortedMultiMap.h"

SMMIterator::SMMIterator(const SortedMultiMap& d) : map(d){
	//TODO - Implementation
}

void SMMIterator::first(){
	//TODO - Implementation
}

void SMMIterator::next(){
	//TODO - Implementation
}

bool SMMIterator::valid() const{
	//TODO - Implementation
	return false;
}

TElem SMMIterator::getCurrent() const{
	//TODO - Implementation
	return NULL_TELEM;
}


