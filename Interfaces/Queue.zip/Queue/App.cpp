#include "Queue.h"
#include "ExtendedTest.h"
#include "ShortTest.h"
#include <iostream>

using namespace std;

int main() {

	testAll();
	testAllExtended();

	cout << "Test end" << endl;

}