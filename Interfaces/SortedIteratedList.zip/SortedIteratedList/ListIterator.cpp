#include "ListIterator.h"
#include "SortedIteratedList.h"
#include <exception>

using namespace std;

ListIterator::ListIterator(const SortedIteratedList& list) : list(list){
	//TODO - Implementation
}

void ListIterator::first(){
	//TODO - Implementation
}

void ListIterator::next(){
	//TODO - Implementation
}

bool ListIterator::valid() const{
	//TODO - Implementation
	return false;
}

TComp ListIterator::getCurrent() const{
	//TODO - Implementation
	return NULL_TCOMP
}


