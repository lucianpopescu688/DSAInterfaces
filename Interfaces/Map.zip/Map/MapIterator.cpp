#include "Map.h"
#include "MapIterator.h"
#include <exception>
using namespace std;


MapIterator::MapIterator(const Map& d) : map(d)
{
	//TODO - Implementation
}


void MapIterator::first() {
	//TODO - Implementation
}


void MapIterator::next() {
	//TODO - Implementation
}


TElem MapIterator::getCurrent(){
	//TODO - Implementation
	return NULL_TELEM;
}


bool MapIterator::valid() const {
	//TODO - Implementation
	return false;
}



