#include "ListIterator.h"
#include "IteratedList.h"
#include <exception>

ListIterator::ListIterator(const IteratedList& list) : list(list) {
	//TODO - Implementation
}

void ListIterator::first() {
	//TODO - Implementation
}

void ListIterator::next() {
	//TODO - Implementation
}

bool ListIterator::valid() const {
	//TODO - Implementation
	return  false;
}

TElem ListIterator::getCurrent() const {
	//TODO - Implementation
	return NULL_TELEM;
}



