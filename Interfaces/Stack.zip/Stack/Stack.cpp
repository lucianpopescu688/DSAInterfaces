#include "Stack.h"
#include <exception>


using namespace std;


Stack::Stack() {
	//TODO - Implementation
}


void Stack::push(TElem e) {
	//TODO - Implementation
}

TElem Stack::top() const {
	//TODO - Implementation
	return NULL_TELEM;
}

TElem Stack::pop() {
	//TODO - Implementation
	return NULL_TELEM;
}


bool Stack::isEmpty() const {
	//TODO - Implementation
	return false;
}

Stack::~Stack() {
	//TODO - Implementation
}